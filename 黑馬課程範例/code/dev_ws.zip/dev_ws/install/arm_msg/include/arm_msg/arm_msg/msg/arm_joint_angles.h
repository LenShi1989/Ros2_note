// generated from rosidl_generator_c/resource/idl.h.em
// with input from arm_msg:msg/ArmJointAngles.idl
// generated code does not contain a copyright notice

#ifndef ARM_MSG__MSG__ARM_JOINT_ANGLES_H_
#define ARM_MSG__MSG__ARM_JOINT_ANGLES_H_

#include "arm_msg/msg/detail/arm_joint_angles__struct.h"
#include "arm_msg/msg/detail/arm_joint_angles__functions.h"
#include "arm_msg/msg/detail/arm_joint_angles__type_support.h"

#endif  // ARM_MSG__MSG__ARM_JOINT_ANGLES_H_
