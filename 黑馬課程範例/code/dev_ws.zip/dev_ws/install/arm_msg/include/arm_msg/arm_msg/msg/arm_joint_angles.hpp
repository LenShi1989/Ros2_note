// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ARM_MSG__MSG__ARM_JOINT_ANGLES_HPP_
#define ARM_MSG__MSG__ARM_JOINT_ANGLES_HPP_

#include "arm_msg/msg/detail/arm_joint_angles__struct.hpp"
#include "arm_msg/msg/detail/arm_joint_angles__builder.hpp"
#include "arm_msg/msg/detail/arm_joint_angles__traits.hpp"
#include "arm_msg/msg/detail/arm_joint_angles__type_support.hpp"

#endif  // ARM_MSG__MSG__ARM_JOINT_ANGLES_HPP_
