// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from arm_msg:msg/ArmJointAngles.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "arm_msg/msg/arm_joint_angles.hpp"


#ifndef ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__BUILDER_HPP_
#define ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "arm_msg/msg/detail/arm_joint_angles__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace arm_msg
{

namespace msg
{

namespace builder
{

class Init_ArmJointAngles_angles
{
public:
  Init_ArmJointAngles_angles()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::arm_msg::msg::ArmJointAngles angles(::arm_msg::msg::ArmJointAngles::_angles_type arg)
  {
    msg_.angles = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_msg::msg::ArmJointAngles msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_msg::msg::ArmJointAngles>()
{
  return arm_msg::msg::builder::Init_ArmJointAngles_angles();
}

}  // namespace arm_msg

#endif  // ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__BUILDER_HPP_
