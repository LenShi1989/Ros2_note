// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from arm_msg:msg/ArmJointAngles.idl
// generated code does not contain a copyright notice

#include "arm_msg/msg/detail/arm_joint_angles__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_arm_msg
const rosidl_type_hash_t *
arm_msg__msg__ArmJointAngles__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x9b, 0x16, 0x17, 0x69, 0xfa, 0xca, 0x54, 0xd4,
      0x27, 0xdb, 0x2b, 0x13, 0x9d, 0x89, 0x49, 0x2c,
      0x08, 0x1e, 0xaf, 0x6f, 0x9f, 0xbd, 0x79, 0x6f,
      0xb6, 0x8a, 0x56, 0xb8, 0x13, 0x8e, 0x93, 0xf1,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char arm_msg__msg__ArmJointAngles__TYPE_NAME[] = "arm_msg/msg/ArmJointAngles";

// Define type names, field names, and default values
static char arm_msg__msg__ArmJointAngles__FIELD_NAME__angles[] = "angles";

static rosidl_runtime_c__type_description__Field arm_msg__msg__ArmJointAngles__FIELDS[] = {
  {
    {arm_msg__msg__ArmJointAngles__FIELD_NAME__angles, 6, 6},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT_ARRAY,
      6,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
arm_msg__msg__ArmJointAngles__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {arm_msg__msg__ArmJointAngles__TYPE_NAME, 26, 26},
      {arm_msg__msg__ArmJointAngles__FIELDS, 1, 1},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "float32[6] angles";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
arm_msg__msg__ArmJointAngles__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {arm_msg__msg__ArmJointAngles__TYPE_NAME, 26, 26},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 17, 17},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
arm_msg__msg__ArmJointAngles__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *arm_msg__msg__ArmJointAngles__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
