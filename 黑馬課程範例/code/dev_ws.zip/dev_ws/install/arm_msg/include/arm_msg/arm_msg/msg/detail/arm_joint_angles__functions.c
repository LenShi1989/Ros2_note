// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from arm_msg:msg/ArmJointAngles.idl
// generated code does not contain a copyright notice
#include "arm_msg/msg/detail/arm_joint_angles__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
arm_msg__msg__ArmJointAngles__init(arm_msg__msg__ArmJointAngles * msg)
{
  if (!msg) {
    return false;
  }
  // angles
  return true;
}

void
arm_msg__msg__ArmJointAngles__fini(arm_msg__msg__ArmJointAngles * msg)
{
  if (!msg) {
    return;
  }
  // angles
}

bool
arm_msg__msg__ArmJointAngles__are_equal(const arm_msg__msg__ArmJointAngles * lhs, const arm_msg__msg__ArmJointAngles * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // angles
  for (size_t i = 0; i < 6; ++i) {
    if (lhs->angles[i] != rhs->angles[i]) {
      return false;
    }
  }
  return true;
}

bool
arm_msg__msg__ArmJointAngles__copy(
  const arm_msg__msg__ArmJointAngles * input,
  arm_msg__msg__ArmJointAngles * output)
{
  if (!input || !output) {
    return false;
  }
  // angles
  for (size_t i = 0; i < 6; ++i) {
    output->angles[i] = input->angles[i];
  }
  return true;
}

arm_msg__msg__ArmJointAngles *
arm_msg__msg__ArmJointAngles__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  arm_msg__msg__ArmJointAngles * msg = (arm_msg__msg__ArmJointAngles *)allocator.allocate(sizeof(arm_msg__msg__ArmJointAngles), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(arm_msg__msg__ArmJointAngles));
  bool success = arm_msg__msg__ArmJointAngles__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
arm_msg__msg__ArmJointAngles__destroy(arm_msg__msg__ArmJointAngles * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    arm_msg__msg__ArmJointAngles__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
arm_msg__msg__ArmJointAngles__Sequence__init(arm_msg__msg__ArmJointAngles__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  arm_msg__msg__ArmJointAngles * data = NULL;

  if (size) {
    data = (arm_msg__msg__ArmJointAngles *)allocator.zero_allocate(size, sizeof(arm_msg__msg__ArmJointAngles), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = arm_msg__msg__ArmJointAngles__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        arm_msg__msg__ArmJointAngles__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
arm_msg__msg__ArmJointAngles__Sequence__fini(arm_msg__msg__ArmJointAngles__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      arm_msg__msg__ArmJointAngles__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

arm_msg__msg__ArmJointAngles__Sequence *
arm_msg__msg__ArmJointAngles__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  arm_msg__msg__ArmJointAngles__Sequence * array = (arm_msg__msg__ArmJointAngles__Sequence *)allocator.allocate(sizeof(arm_msg__msg__ArmJointAngles__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = arm_msg__msg__ArmJointAngles__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
arm_msg__msg__ArmJointAngles__Sequence__destroy(arm_msg__msg__ArmJointAngles__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    arm_msg__msg__ArmJointAngles__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
arm_msg__msg__ArmJointAngles__Sequence__are_equal(const arm_msg__msg__ArmJointAngles__Sequence * lhs, const arm_msg__msg__ArmJointAngles__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!arm_msg__msg__ArmJointAngles__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
arm_msg__msg__ArmJointAngles__Sequence__copy(
  const arm_msg__msg__ArmJointAngles__Sequence * input,
  arm_msg__msg__ArmJointAngles__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(arm_msg__msg__ArmJointAngles);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    arm_msg__msg__ArmJointAngles * data =
      (arm_msg__msg__ArmJointAngles *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!arm_msg__msg__ArmJointAngles__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          arm_msg__msg__ArmJointAngles__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!arm_msg__msg__ArmJointAngles__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
