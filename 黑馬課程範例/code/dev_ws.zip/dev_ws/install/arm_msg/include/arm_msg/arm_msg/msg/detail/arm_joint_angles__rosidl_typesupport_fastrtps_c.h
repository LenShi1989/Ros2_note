// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from arm_msg:msg/ArmJointAngles.idl
// generated code does not contain a copyright notice
#ifndef ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "arm_msg/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "arm_msg/msg/detail/arm_joint_angles__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
bool cdr_serialize_arm_msg__msg__ArmJointAngles(
  const arm_msg__msg__ArmJointAngles * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
bool cdr_deserialize_arm_msg__msg__ArmJointAngles(
  eprosima::fastcdr::Cdr &,
  arm_msg__msg__ArmJointAngles * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t get_serialized_size_arm_msg__msg__ArmJointAngles(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t max_serialized_size_arm_msg__msg__ArmJointAngles(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
bool cdr_serialize_key_arm_msg__msg__ArmJointAngles(
  const arm_msg__msg__ArmJointAngles * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t get_serialized_size_key_arm_msg__msg__ArmJointAngles(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t max_serialized_size_key_arm_msg__msg__ArmJointAngles(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, arm_msg, msg, ArmJointAngles)();

#ifdef __cplusplus
}
#endif

#endif  // ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
