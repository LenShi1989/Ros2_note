// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from arm_msg:msg/ArmJointAngles.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "arm_msg/msg/arm_joint_angles.h"


#ifndef ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__STRUCT_H_
#define ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/ArmJointAngles in the package arm_msg.
typedef struct arm_msg__msg__ArmJointAngles
{
  float angles[6];
} arm_msg__msg__ArmJointAngles;

// Struct for a sequence of arm_msg__msg__ArmJointAngles.
typedef struct arm_msg__msg__ArmJointAngles__Sequence
{
  arm_msg__msg__ArmJointAngles * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} arm_msg__msg__ArmJointAngles__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__STRUCT_H_
