// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from arm_msg:msg/ArmJointAngles.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "arm_msg/msg/arm_joint_angles.hpp"


#ifndef ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__STRUCT_HPP_
#define ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__arm_msg__msg__ArmJointAngles __attribute__((deprecated))
#else
# define DEPRECATED__arm_msg__msg__ArmJointAngles __declspec(deprecated)
#endif

namespace arm_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ArmJointAngles_
{
  using Type = ArmJointAngles_<ContainerAllocator>;

  explicit ArmJointAngles_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<float, 6>::iterator, float>(this->angles.begin(), this->angles.end(), 0.0f);
    }
  }

  explicit ArmJointAngles_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : angles(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<float, 6>::iterator, float>(this->angles.begin(), this->angles.end(), 0.0f);
    }
  }

  // field types and members
  using _angles_type =
    std::array<float, 6>;
  _angles_type angles;

  // setters for named parameter idiom
  Type & set__angles(
    const std::array<float, 6> & _arg)
  {
    this->angles = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    arm_msg::msg::ArmJointAngles_<ContainerAllocator> *;
  using ConstRawPtr =
    const arm_msg::msg::ArmJointAngles_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<arm_msg::msg::ArmJointAngles_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<arm_msg::msg::ArmJointAngles_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      arm_msg::msg::ArmJointAngles_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<arm_msg::msg::ArmJointAngles_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      arm_msg::msg::ArmJointAngles_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<arm_msg::msg::ArmJointAngles_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<arm_msg::msg::ArmJointAngles_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<arm_msg::msg::ArmJointAngles_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__arm_msg__msg__ArmJointAngles
    std::shared_ptr<arm_msg::msg::ArmJointAngles_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__arm_msg__msg__ArmJointAngles
    std::shared_ptr<arm_msg::msg::ArmJointAngles_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ArmJointAngles_ & other) const
  {
    if (this->angles != other.angles) {
      return false;
    }
    return true;
  }
  bool operator!=(const ArmJointAngles_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ArmJointAngles_

// alias to use template instance with default allocator
using ArmJointAngles =
  arm_msg::msg::ArmJointAngles_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace arm_msg

#endif  // ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__STRUCT_HPP_
