// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from arm_msg:msg/ArmJointAngles.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "arm_msg/msg/arm_joint_angles.hpp"


#ifndef ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__TRAITS_HPP_
#define ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "arm_msg/msg/detail/arm_joint_angles__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace arm_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const ArmJointAngles & msg,
  std::ostream & out)
{
  out << "{";
  // member: angles
  {
    if (msg.angles.size() == 0) {
      out << "angles: []";
    } else {
      out << "angles: [";
      size_t pending_items = msg.angles.size();
      for (auto item : msg.angles) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ArmJointAngles & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: angles
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.angles.size() == 0) {
      out << "angles: []\n";
    } else {
      out << "angles:\n";
      for (auto item : msg.angles) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ArmJointAngles & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace arm_msg

namespace rosidl_generator_traits
{

[[deprecated("use arm_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const arm_msg::msg::ArmJointAngles & msg,
  std::ostream & out, size_t indentation = 0)
{
  arm_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use arm_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const arm_msg::msg::ArmJointAngles & msg)
{
  return arm_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<arm_msg::msg::ArmJointAngles>()
{
  return "arm_msg::msg::ArmJointAngles";
}

template<>
inline const char * name<arm_msg::msg::ArmJointAngles>()
{
  return "arm_msg/msg/ArmJointAngles";
}

template<>
struct has_fixed_size<arm_msg::msg::ArmJointAngles>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<arm_msg::msg::ArmJointAngles>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<arm_msg::msg::ArmJointAngles>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__TRAITS_HPP_
