// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from arm_msg:msg/ArmJointAngles.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "arm_msg/msg/detail/arm_joint_angles__functions.h"
#include "arm_msg/msg/detail/arm_joint_angles__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace arm_msg
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void ArmJointAngles_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) arm_msg::msg::ArmJointAngles(_init);
}

void ArmJointAngles_fini_function(void * message_memory)
{
  auto typed_message = static_cast<arm_msg::msg::ArmJointAngles *>(message_memory);
  typed_message->~ArmJointAngles();
}

size_t size_function__ArmJointAngles__angles(const void * untyped_member)
{
  (void)untyped_member;
  return 6;
}

const void * get_const_function__ArmJointAngles__angles(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<float, 6> *>(untyped_member);
  return &member[index];
}

void * get_function__ArmJointAngles__angles(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<float, 6> *>(untyped_member);
  return &member[index];
}

void fetch_function__ArmJointAngles__angles(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__ArmJointAngles__angles(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__ArmJointAngles__angles(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__ArmJointAngles__angles(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember ArmJointAngles_message_member_array[1] = {
  {
    "angles",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    true,  // is array
    6,  // array size
    false,  // is upper bound
    offsetof(arm_msg::msg::ArmJointAngles, angles),  // bytes offset in struct
    nullptr,  // default value
    size_function__ArmJointAngles__angles,  // size() function pointer
    get_const_function__ArmJointAngles__angles,  // get_const(index) function pointer
    get_function__ArmJointAngles__angles,  // get(index) function pointer
    fetch_function__ArmJointAngles__angles,  // fetch(index, &value) function pointer
    assign_function__ArmJointAngles__angles,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers ArmJointAngles_message_members = {
  "arm_msg::msg",  // message namespace
  "ArmJointAngles",  // message name
  1,  // number of fields
  sizeof(arm_msg::msg::ArmJointAngles),
  false,  // has_any_key_member_
  ArmJointAngles_message_member_array,  // message members
  ArmJointAngles_init_function,  // function to initialize message memory (memory has to be allocated)
  ArmJointAngles_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t ArmJointAngles_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &ArmJointAngles_message_members,
  get_message_typesupport_handle_function,
  &arm_msg__msg__ArmJointAngles__get_type_hash,
  &arm_msg__msg__ArmJointAngles__get_type_description,
  &arm_msg__msg__ArmJointAngles__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace arm_msg


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<arm_msg::msg::ArmJointAngles>()
{
  return &::arm_msg::msg::rosidl_typesupport_introspection_cpp::ArmJointAngles_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, arm_msg, msg, ArmJointAngles)() {
  return &::arm_msg::msg::rosidl_typesupport_introspection_cpp::ArmJointAngles_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
