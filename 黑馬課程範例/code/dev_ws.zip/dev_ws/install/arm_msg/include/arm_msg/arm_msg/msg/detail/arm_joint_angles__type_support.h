// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from arm_msg:msg/ArmJointAngles.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "arm_msg/msg/arm_joint_angles.h"


#ifndef ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__TYPE_SUPPORT_H_
#define ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "arm_msg/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_arm_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  arm_msg,
  msg,
  ArmJointAngles
)(void);

#ifdef __cplusplus
}
#endif

#endif  // ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__TYPE_SUPPORT_H_
