// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from arm_msg:msg/ArmJointAngles.idl
// generated code does not contain a copyright notice

#ifndef ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__TYPE_SUPPORT_HPP_
#define ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "arm_msg/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_arm_msg
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  arm_msg,
  msg,
  ArmJointAngles
)();
#ifdef __cplusplus
}
#endif

#endif  // ARM_MSG__MSG__DETAIL__ARM_JOINT_ANGLES__TYPE_SUPPORT_HPP_
