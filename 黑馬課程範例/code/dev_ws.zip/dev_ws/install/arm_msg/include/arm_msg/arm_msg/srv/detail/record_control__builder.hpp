// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from arm_msg:srv/RecordControl.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "arm_msg/srv/record_control.hpp"


#ifndef ARM_MSG__SRV__DETAIL__RECORD_CONTROL__BUILDER_HPP_
#define ARM_MSG__SRV__DETAIL__RECORD_CONTROL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "arm_msg/srv/detail/record_control__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace arm_msg
{

namespace srv
{

namespace builder
{

class Init_RecordControl_Request_filename
{
public:
  explicit Init_RecordControl_Request_filename(::arm_msg::srv::RecordControl_Request & msg)
  : msg_(msg)
  {}
  ::arm_msg::srv::RecordControl_Request filename(::arm_msg::srv::RecordControl_Request::_filename_type arg)
  {
    msg_.filename = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_msg::srv::RecordControl_Request msg_;
};

class Init_RecordControl_Request_action
{
public:
  Init_RecordControl_Request_action()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RecordControl_Request_filename action(::arm_msg::srv::RecordControl_Request::_action_type arg)
  {
    msg_.action = std::move(arg);
    return Init_RecordControl_Request_filename(msg_);
  }

private:
  ::arm_msg::srv::RecordControl_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_msg::srv::RecordControl_Request>()
{
  return arm_msg::srv::builder::Init_RecordControl_Request_action();
}

}  // namespace arm_msg


namespace arm_msg
{

namespace srv
{

namespace builder
{

class Init_RecordControl_Response_message
{
public:
  explicit Init_RecordControl_Response_message(::arm_msg::srv::RecordControl_Response & msg)
  : msg_(msg)
  {}
  ::arm_msg::srv::RecordControl_Response message(::arm_msg::srv::RecordControl_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_msg::srv::RecordControl_Response msg_;
};

class Init_RecordControl_Response_success
{
public:
  Init_RecordControl_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RecordControl_Response_message success(::arm_msg::srv::RecordControl_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_RecordControl_Response_message(msg_);
  }

private:
  ::arm_msg::srv::RecordControl_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_msg::srv::RecordControl_Response>()
{
  return arm_msg::srv::builder::Init_RecordControl_Response_success();
}

}  // namespace arm_msg


namespace arm_msg
{

namespace srv
{

namespace builder
{

class Init_RecordControl_Event_response
{
public:
  explicit Init_RecordControl_Event_response(::arm_msg::srv::RecordControl_Event & msg)
  : msg_(msg)
  {}
  ::arm_msg::srv::RecordControl_Event response(::arm_msg::srv::RecordControl_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::arm_msg::srv::RecordControl_Event msg_;
};

class Init_RecordControl_Event_request
{
public:
  explicit Init_RecordControl_Event_request(::arm_msg::srv::RecordControl_Event & msg)
  : msg_(msg)
  {}
  Init_RecordControl_Event_response request(::arm_msg::srv::RecordControl_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_RecordControl_Event_response(msg_);
  }

private:
  ::arm_msg::srv::RecordControl_Event msg_;
};

class Init_RecordControl_Event_info
{
public:
  Init_RecordControl_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RecordControl_Event_request info(::arm_msg::srv::RecordControl_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_RecordControl_Event_request(msg_);
  }

private:
  ::arm_msg::srv::RecordControl_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::arm_msg::srv::RecordControl_Event>()
{
  return arm_msg::srv::builder::Init_RecordControl_Event_info();
}

}  // namespace arm_msg

#endif  // ARM_MSG__SRV__DETAIL__RECORD_CONTROL__BUILDER_HPP_
