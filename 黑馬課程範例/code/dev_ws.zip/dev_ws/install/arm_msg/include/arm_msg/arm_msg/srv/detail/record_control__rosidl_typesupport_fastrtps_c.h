// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from arm_msg:srv/RecordControl.idl
// generated code does not contain a copyright notice
#ifndef ARM_MSG__SRV__DETAIL__RECORD_CONTROL__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define ARM_MSG__SRV__DETAIL__RECORD_CONTROL__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "arm_msg/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "arm_msg/srv/detail/record_control__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
bool cdr_serialize_arm_msg__srv__RecordControl_Request(
  const arm_msg__srv__RecordControl_Request * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
bool cdr_deserialize_arm_msg__srv__RecordControl_Request(
  eprosima::fastcdr::Cdr &,
  arm_msg__srv__RecordControl_Request * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t get_serialized_size_arm_msg__srv__RecordControl_Request(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t max_serialized_size_arm_msg__srv__RecordControl_Request(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
bool cdr_serialize_key_arm_msg__srv__RecordControl_Request(
  const arm_msg__srv__RecordControl_Request * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t get_serialized_size_key_arm_msg__srv__RecordControl_Request(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t max_serialized_size_key_arm_msg__srv__RecordControl_Request(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, arm_msg, srv, RecordControl_Request)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "arm_msg/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "arm_msg/srv/detail/record_control__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
bool cdr_serialize_arm_msg__srv__RecordControl_Response(
  const arm_msg__srv__RecordControl_Response * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
bool cdr_deserialize_arm_msg__srv__RecordControl_Response(
  eprosima::fastcdr::Cdr &,
  arm_msg__srv__RecordControl_Response * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t get_serialized_size_arm_msg__srv__RecordControl_Response(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t max_serialized_size_arm_msg__srv__RecordControl_Response(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
bool cdr_serialize_key_arm_msg__srv__RecordControl_Response(
  const arm_msg__srv__RecordControl_Response * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t get_serialized_size_key_arm_msg__srv__RecordControl_Response(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t max_serialized_size_key_arm_msg__srv__RecordControl_Response(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, arm_msg, srv, RecordControl_Response)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "arm_msg/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "arm_msg/srv/detail/record_control__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
bool cdr_serialize_arm_msg__srv__RecordControl_Event(
  const arm_msg__srv__RecordControl_Event * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
bool cdr_deserialize_arm_msg__srv__RecordControl_Event(
  eprosima::fastcdr::Cdr &,
  arm_msg__srv__RecordControl_Event * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t get_serialized_size_arm_msg__srv__RecordControl_Event(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t max_serialized_size_arm_msg__srv__RecordControl_Event(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
bool cdr_serialize_key_arm_msg__srv__RecordControl_Event(
  const arm_msg__srv__RecordControl_Event * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t get_serialized_size_key_arm_msg__srv__RecordControl_Event(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
size_t max_serialized_size_key_arm_msg__srv__RecordControl_Event(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, arm_msg, srv, RecordControl_Event)();

#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "arm_msg/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_arm_msg
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, arm_msg, srv, RecordControl)();

#ifdef __cplusplus
}
#endif

#endif  // ARM_MSG__SRV__DETAIL__RECORD_CONTROL__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
