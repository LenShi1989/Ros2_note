// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from arm_msg:srv/RecordControl.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "arm_msg/srv/record_control.h"


#ifndef ARM_MSG__SRV__DETAIL__RECORD_CONTROL__STRUCT_H_
#define ARM_MSG__SRV__DETAIL__RECORD_CONTROL__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'action'
// Member 'filename'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/RecordControl in the package arm_msg.
typedef struct arm_msg__srv__RecordControl_Request
{
  rosidl_runtime_c__String action;
  rosidl_runtime_c__String filename;
} arm_msg__srv__RecordControl_Request;

// Struct for a sequence of arm_msg__srv__RecordControl_Request.
typedef struct arm_msg__srv__RecordControl_Request__Sequence
{
  arm_msg__srv__RecordControl_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} arm_msg__srv__RecordControl_Request__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'message'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in srv/RecordControl in the package arm_msg.
typedef struct arm_msg__srv__RecordControl_Response
{
  bool success;
  rosidl_runtime_c__String message;
} arm_msg__srv__RecordControl_Response;

// Struct for a sequence of arm_msg__srv__RecordControl_Response.
typedef struct arm_msg__srv__RecordControl_Response__Sequence
{
  arm_msg__srv__RecordControl_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} arm_msg__srv__RecordControl_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  arm_msg__srv__RecordControl_Event__request__MAX_SIZE = 1
};
// response
enum
{
  arm_msg__srv__RecordControl_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/RecordControl in the package arm_msg.
typedef struct arm_msg__srv__RecordControl_Event
{
  service_msgs__msg__ServiceEventInfo info;
  arm_msg__srv__RecordControl_Request__Sequence request;
  arm_msg__srv__RecordControl_Response__Sequence response;
} arm_msg__srv__RecordControl_Event;

// Struct for a sequence of arm_msg__srv__RecordControl_Event.
typedef struct arm_msg__srv__RecordControl_Event__Sequence
{
  arm_msg__srv__RecordControl_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} arm_msg__srv__RecordControl_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ARM_MSG__SRV__DETAIL__RECORD_CONTROL__STRUCT_H_
