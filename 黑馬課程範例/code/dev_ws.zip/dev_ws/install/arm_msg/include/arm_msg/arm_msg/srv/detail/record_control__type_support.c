// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from arm_msg:srv/RecordControl.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "arm_msg/srv/detail/record_control__rosidl_typesupport_introspection_c.h"
#include "arm_msg/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "arm_msg/srv/detail/record_control__functions.h"
#include "arm_msg/srv/detail/record_control__struct.h"


// Include directives for member types
// Member `action`
// Member `filename`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void arm_msg__srv__RecordControl_Request__rosidl_typesupport_introspection_c__RecordControl_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  arm_msg__srv__RecordControl_Request__init(message_memory);
}

void arm_msg__srv__RecordControl_Request__rosidl_typesupport_introspection_c__RecordControl_Request_fini_function(void * message_memory)
{
  arm_msg__srv__RecordControl_Request__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember arm_msg__srv__RecordControl_Request__rosidl_typesupport_introspection_c__RecordControl_Request_message_member_array[2] = {
  {
    "action",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(arm_msg__srv__RecordControl_Request, action),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "filename",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(arm_msg__srv__RecordControl_Request, filename),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers arm_msg__srv__RecordControl_Request__rosidl_typesupport_introspection_c__RecordControl_Request_message_members = {
  "arm_msg__srv",  // message namespace
  "RecordControl_Request",  // message name
  2,  // number of fields
  sizeof(arm_msg__srv__RecordControl_Request),
  false,  // has_any_key_member_
  arm_msg__srv__RecordControl_Request__rosidl_typesupport_introspection_c__RecordControl_Request_message_member_array,  // message members
  arm_msg__srv__RecordControl_Request__rosidl_typesupport_introspection_c__RecordControl_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  arm_msg__srv__RecordControl_Request__rosidl_typesupport_introspection_c__RecordControl_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t arm_msg__srv__RecordControl_Request__rosidl_typesupport_introspection_c__RecordControl_Request_message_type_support_handle = {
  0,
  &arm_msg__srv__RecordControl_Request__rosidl_typesupport_introspection_c__RecordControl_Request_message_members,
  get_message_typesupport_handle_function,
  &arm_msg__srv__RecordControl_Request__get_type_hash,
  &arm_msg__srv__RecordControl_Request__get_type_description,
  &arm_msg__srv__RecordControl_Request__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_arm_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, arm_msg, srv, RecordControl_Request)() {
  if (!arm_msg__srv__RecordControl_Request__rosidl_typesupport_introspection_c__RecordControl_Request_message_type_support_handle.typesupport_identifier) {
    arm_msg__srv__RecordControl_Request__rosidl_typesupport_introspection_c__RecordControl_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &arm_msg__srv__RecordControl_Request__rosidl_typesupport_introspection_c__RecordControl_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "arm_msg/srv/detail/record_control__rosidl_typesupport_introspection_c.h"
// already included above
// #include "arm_msg/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "arm_msg/srv/detail/record_control__functions.h"
// already included above
// #include "arm_msg/srv/detail/record_control__struct.h"


// Include directives for member types
// Member `message`
// already included above
// #include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void arm_msg__srv__RecordControl_Response__rosidl_typesupport_introspection_c__RecordControl_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  arm_msg__srv__RecordControl_Response__init(message_memory);
}

void arm_msg__srv__RecordControl_Response__rosidl_typesupport_introspection_c__RecordControl_Response_fini_function(void * message_memory)
{
  arm_msg__srv__RecordControl_Response__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember arm_msg__srv__RecordControl_Response__rosidl_typesupport_introspection_c__RecordControl_Response_message_member_array[2] = {
  {
    "success",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(arm_msg__srv__RecordControl_Response, success),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "message",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(arm_msg__srv__RecordControl_Response, message),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers arm_msg__srv__RecordControl_Response__rosidl_typesupport_introspection_c__RecordControl_Response_message_members = {
  "arm_msg__srv",  // message namespace
  "RecordControl_Response",  // message name
  2,  // number of fields
  sizeof(arm_msg__srv__RecordControl_Response),
  false,  // has_any_key_member_
  arm_msg__srv__RecordControl_Response__rosidl_typesupport_introspection_c__RecordControl_Response_message_member_array,  // message members
  arm_msg__srv__RecordControl_Response__rosidl_typesupport_introspection_c__RecordControl_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  arm_msg__srv__RecordControl_Response__rosidl_typesupport_introspection_c__RecordControl_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t arm_msg__srv__RecordControl_Response__rosidl_typesupport_introspection_c__RecordControl_Response_message_type_support_handle = {
  0,
  &arm_msg__srv__RecordControl_Response__rosidl_typesupport_introspection_c__RecordControl_Response_message_members,
  get_message_typesupport_handle_function,
  &arm_msg__srv__RecordControl_Response__get_type_hash,
  &arm_msg__srv__RecordControl_Response__get_type_description,
  &arm_msg__srv__RecordControl_Response__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_arm_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, arm_msg, srv, RecordControl_Response)() {
  if (!arm_msg__srv__RecordControl_Response__rosidl_typesupport_introspection_c__RecordControl_Response_message_type_support_handle.typesupport_identifier) {
    arm_msg__srv__RecordControl_Response__rosidl_typesupport_introspection_c__RecordControl_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &arm_msg__srv__RecordControl_Response__rosidl_typesupport_introspection_c__RecordControl_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "arm_msg/srv/detail/record_control__rosidl_typesupport_introspection_c.h"
// already included above
// #include "arm_msg/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "arm_msg/srv/detail/record_control__functions.h"
// already included above
// #include "arm_msg/srv/detail/record_control__struct.h"


// Include directives for member types
// Member `info`
#include "service_msgs/msg/service_event_info.h"
// Member `info`
#include "service_msgs/msg/detail/service_event_info__rosidl_typesupport_introspection_c.h"
// Member `request`
// Member `response`
#include "arm_msg/srv/record_control.h"
// Member `request`
// Member `response`
// already included above
// #include "arm_msg/srv/detail/record_control__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  arm_msg__srv__RecordControl_Event__init(message_memory);
}

void arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_fini_function(void * message_memory)
{
  arm_msg__srv__RecordControl_Event__fini(message_memory);
}

size_t arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__size_function__RecordControl_Event__request(
  const void * untyped_member)
{
  const arm_msg__srv__RecordControl_Request__Sequence * member =
    (const arm_msg__srv__RecordControl_Request__Sequence *)(untyped_member);
  return member->size;
}

const void * arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__get_const_function__RecordControl_Event__request(
  const void * untyped_member, size_t index)
{
  const arm_msg__srv__RecordControl_Request__Sequence * member =
    (const arm_msg__srv__RecordControl_Request__Sequence *)(untyped_member);
  return &member->data[index];
}

void * arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__get_function__RecordControl_Event__request(
  void * untyped_member, size_t index)
{
  arm_msg__srv__RecordControl_Request__Sequence * member =
    (arm_msg__srv__RecordControl_Request__Sequence *)(untyped_member);
  return &member->data[index];
}

void arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__fetch_function__RecordControl_Event__request(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const arm_msg__srv__RecordControl_Request * item =
    ((const arm_msg__srv__RecordControl_Request *)
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__get_const_function__RecordControl_Event__request(untyped_member, index));
  arm_msg__srv__RecordControl_Request * value =
    (arm_msg__srv__RecordControl_Request *)(untyped_value);
  *value = *item;
}

void arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__assign_function__RecordControl_Event__request(
  void * untyped_member, size_t index, const void * untyped_value)
{
  arm_msg__srv__RecordControl_Request * item =
    ((arm_msg__srv__RecordControl_Request *)
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__get_function__RecordControl_Event__request(untyped_member, index));
  const arm_msg__srv__RecordControl_Request * value =
    (const arm_msg__srv__RecordControl_Request *)(untyped_value);
  *item = *value;
}

bool arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__resize_function__RecordControl_Event__request(
  void * untyped_member, size_t size)
{
  arm_msg__srv__RecordControl_Request__Sequence * member =
    (arm_msg__srv__RecordControl_Request__Sequence *)(untyped_member);
  arm_msg__srv__RecordControl_Request__Sequence__fini(member);
  return arm_msg__srv__RecordControl_Request__Sequence__init(member, size);
}

size_t arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__size_function__RecordControl_Event__response(
  const void * untyped_member)
{
  const arm_msg__srv__RecordControl_Response__Sequence * member =
    (const arm_msg__srv__RecordControl_Response__Sequence *)(untyped_member);
  return member->size;
}

const void * arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__get_const_function__RecordControl_Event__response(
  const void * untyped_member, size_t index)
{
  const arm_msg__srv__RecordControl_Response__Sequence * member =
    (const arm_msg__srv__RecordControl_Response__Sequence *)(untyped_member);
  return &member->data[index];
}

void * arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__get_function__RecordControl_Event__response(
  void * untyped_member, size_t index)
{
  arm_msg__srv__RecordControl_Response__Sequence * member =
    (arm_msg__srv__RecordControl_Response__Sequence *)(untyped_member);
  return &member->data[index];
}

void arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__fetch_function__RecordControl_Event__response(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const arm_msg__srv__RecordControl_Response * item =
    ((const arm_msg__srv__RecordControl_Response *)
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__get_const_function__RecordControl_Event__response(untyped_member, index));
  arm_msg__srv__RecordControl_Response * value =
    (arm_msg__srv__RecordControl_Response *)(untyped_value);
  *value = *item;
}

void arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__assign_function__RecordControl_Event__response(
  void * untyped_member, size_t index, const void * untyped_value)
{
  arm_msg__srv__RecordControl_Response * item =
    ((arm_msg__srv__RecordControl_Response *)
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__get_function__RecordControl_Event__response(untyped_member, index));
  const arm_msg__srv__RecordControl_Response * value =
    (const arm_msg__srv__RecordControl_Response *)(untyped_value);
  *item = *value;
}

bool arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__resize_function__RecordControl_Event__response(
  void * untyped_member, size_t size)
{
  arm_msg__srv__RecordControl_Response__Sequence * member =
    (arm_msg__srv__RecordControl_Response__Sequence *)(untyped_member);
  arm_msg__srv__RecordControl_Response__Sequence__fini(member);
  return arm_msg__srv__RecordControl_Response__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_message_member_array[3] = {
  {
    "info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(arm_msg__srv__RecordControl_Event, info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "request",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    true,  // is array
    1,  // array size
    true,  // is upper bound
    offsetof(arm_msg__srv__RecordControl_Event, request),  // bytes offset in struct
    NULL,  // default value
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__size_function__RecordControl_Event__request,  // size() function pointer
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__get_const_function__RecordControl_Event__request,  // get_const(index) function pointer
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__get_function__RecordControl_Event__request,  // get(index) function pointer
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__fetch_function__RecordControl_Event__request,  // fetch(index, &value) function pointer
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__assign_function__RecordControl_Event__request,  // assign(index, value) function pointer
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__resize_function__RecordControl_Event__request  // resize(index) function pointer
  },
  {
    "response",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    true,  // is array
    1,  // array size
    true,  // is upper bound
    offsetof(arm_msg__srv__RecordControl_Event, response),  // bytes offset in struct
    NULL,  // default value
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__size_function__RecordControl_Event__response,  // size() function pointer
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__get_const_function__RecordControl_Event__response,  // get_const(index) function pointer
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__get_function__RecordControl_Event__response,  // get(index) function pointer
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__fetch_function__RecordControl_Event__response,  // fetch(index, &value) function pointer
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__assign_function__RecordControl_Event__response,  // assign(index, value) function pointer
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__resize_function__RecordControl_Event__response  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_message_members = {
  "arm_msg__srv",  // message namespace
  "RecordControl_Event",  // message name
  3,  // number of fields
  sizeof(arm_msg__srv__RecordControl_Event),
  false,  // has_any_key_member_
  arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_message_member_array,  // message members
  arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_init_function,  // function to initialize message memory (memory has to be allocated)
  arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_message_type_support_handle = {
  0,
  &arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_message_members,
  get_message_typesupport_handle_function,
  &arm_msg__srv__RecordControl_Event__get_type_hash,
  &arm_msg__srv__RecordControl_Event__get_type_description,
  &arm_msg__srv__RecordControl_Event__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_arm_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, arm_msg, srv, RecordControl_Event)() {
  arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, service_msgs, msg, ServiceEventInfo)();
  arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, arm_msg, srv, RecordControl_Request)();
  arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, arm_msg, srv, RecordControl_Response)();
  if (!arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_message_type_support_handle.typesupport_identifier) {
    arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "arm_msg/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "arm_msg/srv/detail/record_control__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers arm_msg__srv__detail__record_control__rosidl_typesupport_introspection_c__RecordControl_service_members = {
  "arm_msg__srv",  // service namespace
  "RecordControl",  // service name
  // the following fields are initialized below on first access
  NULL,  // request message
  // arm_msg__srv__detail__record_control__rosidl_typesupport_introspection_c__RecordControl_Request_message_type_support_handle,
  NULL,  // response message
  // arm_msg__srv__detail__record_control__rosidl_typesupport_introspection_c__RecordControl_Response_message_type_support_handle
  NULL  // event_message
  // arm_msg__srv__detail__record_control__rosidl_typesupport_introspection_c__RecordControl_Response_message_type_support_handle
};


static rosidl_service_type_support_t arm_msg__srv__detail__record_control__rosidl_typesupport_introspection_c__RecordControl_service_type_support_handle = {
  0,
  &arm_msg__srv__detail__record_control__rosidl_typesupport_introspection_c__RecordControl_service_members,
  get_service_typesupport_handle_function,
  &arm_msg__srv__RecordControl_Request__rosidl_typesupport_introspection_c__RecordControl_Request_message_type_support_handle,
  &arm_msg__srv__RecordControl_Response__rosidl_typesupport_introspection_c__RecordControl_Response_message_type_support_handle,
  &arm_msg__srv__RecordControl_Event__rosidl_typesupport_introspection_c__RecordControl_Event_message_type_support_handle,
  ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_CREATE_EVENT_MESSAGE_SYMBOL_NAME(
    rosidl_typesupport_c,
    arm_msg,
    srv,
    RecordControl
  ),
  ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_DESTROY_EVENT_MESSAGE_SYMBOL_NAME(
    rosidl_typesupport_c,
    arm_msg,
    srv,
    RecordControl
  ),
  &arm_msg__srv__RecordControl__get_type_hash,
  &arm_msg__srv__RecordControl__get_type_description,
  &arm_msg__srv__RecordControl__get_type_description_sources,
};

// Forward declaration of message type support functions for service members
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, arm_msg, srv, RecordControl_Request)(void);

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, arm_msg, srv, RecordControl_Response)(void);

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, arm_msg, srv, RecordControl_Event)(void);

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_arm_msg
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, arm_msg, srv, RecordControl)(void) {
  if (!arm_msg__srv__detail__record_control__rosidl_typesupport_introspection_c__RecordControl_service_type_support_handle.typesupport_identifier) {
    arm_msg__srv__detail__record_control__rosidl_typesupport_introspection_c__RecordControl_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)arm_msg__srv__detail__record_control__rosidl_typesupport_introspection_c__RecordControl_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, arm_msg, srv, RecordControl_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, arm_msg, srv, RecordControl_Response)()->data;
  }
  if (!service_members->event_members_) {
    service_members->event_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, arm_msg, srv, RecordControl_Event)()->data;
  }

  return &arm_msg__srv__detail__record_control__rosidl_typesupport_introspection_c__RecordControl_service_type_support_handle;
}
