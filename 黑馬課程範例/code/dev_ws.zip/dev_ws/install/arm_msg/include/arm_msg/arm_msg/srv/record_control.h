// generated from rosidl_generator_c/resource/idl.h.em
// with input from arm_msg:srv/RecordControl.idl
// generated code does not contain a copyright notice

#ifndef ARM_MSG__SRV__RECORD_CONTROL_H_
#define ARM_MSG__SRV__RECORD_CONTROL_H_

#include "arm_msg/srv/detail/record_control__struct.h"
#include "arm_msg/srv/detail/record_control__functions.h"
#include "arm_msg/srv/detail/record_control__type_support.h"

#endif  // ARM_MSG__SRV__RECORD_CONTROL_H_
