// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ARM_MSG__SRV__RECORD_CONTROL_HPP_
#define ARM_MSG__SRV__RECORD_CONTROL_HPP_

#include "arm_msg/srv/detail/record_control__struct.hpp"
#include "arm_msg/srv/detail/record_control__builder.hpp"
#include "arm_msg/srv/detail/record_control__traits.hpp"
#include "arm_msg/srv/detail/record_control__type_support.hpp"

#endif  // ARM_MSG__SRV__RECORD_CONTROL_HPP_
