# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(arm_msg_IDL_FILES "msg/ArmJointAngles.idl;srv/RecordControl.idl")
set(arm_msg_INTERFACE_FILES "msg/ArmJointAngles.msg;srv/RecordControl.srv")
