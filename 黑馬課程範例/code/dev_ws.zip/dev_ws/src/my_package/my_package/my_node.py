def main():
    print('Hi from itheima.')


if __name__ == '__main__':
    main()
